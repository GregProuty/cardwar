var indexOfCards = [

    {        picture: "1.png",
        value: 14,
        name: "AC"
    },
    {        picture: "2.png",
        value: 14,
        name: "AS"
    },
    {        picture: "3.png",
        value: 14,
        name: "AH"
    },
    {        picture: "4.png",
        value:  14,
        name: "AD"
    },
    {        picture: "5.png",
        value: 13,
        name: "KC"
    },
    {        picture: "6.png",
        value: 13,
        name: "KS"
    },
    {        picture: "7.png",
        value: 13,
        name: "KH"
    },
    {        picture: "8.png",
        value: 13,
        name: "KD"
    },
    {        picture: "9.png",
        value: 12,
        name: "QC"
    },
    {
        picture: "10.png",
        value: 12,
        name: "QS"
    },
    {
        picture: "11.png",
        value: 12,
        name: "QH"
    },
    {
        picture: "12.png",
        value: 12,
        name: "QD"
    },
    {
        picture: "13.png",
        value: 11,
        name: "JC"
    },
    {
        picture: "14.png",
        value: 11,
        name: "JS"
    },
    {
        picture: "15.png",
        value: 11,
        name: "JH"
    },
    {
        picture: "16.png",
        value: 11,
        name: "JD"
    },
    {
        picture: "17.png",
        value: 10,
        name: "10C"
    },
    {
        picture: "18.png",
        value: 10,
        name: "10S"
    },
    {
        picture: "19.png",
        value: 10,
        name: "10H"
    },
    {
        picture: "20.png",
        value: 10,
        name: "10D"
    },
    {
        picture: "21.png",
        value: 9,
        name: "9C"
    },
    {
        picture: "22.png",
        value: 9,
        name: "9S"
    },
    {
        picture: "23.png",
        value: 9,
        name: "9H"
    },
    {
        picture: "24.png",
        value: 9,
        name: "9D"
    },
    {
        picture: "25.png",
        value: 8,
        name: "8C"
    },
    {
        picture: "26.png",
        value: 8,
        name: "8S"
    },
    {
        picture: "27.png",
        value: 8,
        name: "8H"
    },
    {
        picture: "28.png",
        value: 8,
        name: "8D"
    },
    {
        picture: "29.png",
        value: 7,
        name: "7C"
    },
    {
        picture: "30.png",
        value: 7,
        name: "7S"
    },
    {
        picture: "31.png",
        value: 7,
        name: "7H"
    },
    {
        picture: "32.png",
        value: 7,
        name: "7D"
    },
    {
        picture: "33.png",
        value: 6,
        name: "6C"
    },
    {
        picture: "34.png",
        value: 6,
        name: "6S"
    },
    {
        picture: "35.png",
        value: 6,
        name: "6H"
    },
    {
        picture: "36.png",
        value: 6,
        name: "6D"
    },
    {
        picture: "37.png",
        value: 5,
        name: "5C"
    },
    {
        picture: "38.png",
        value: 5,
        name: "5S"
    },
    {
        picture: "39.png",
        value: 5,
        name: "5H"
    },
    {
        picture: "40.png",
        value: 5,
        name: "5D"
    },
    {
        picture: "41.png",
        value: 4,
        name: "4C"
    },
    {
        picture: "42.png",
        value: 4,
        name: "4S"
    },
    {
        picture: "43.png",
        value: 4,
        name: "4H"
    },
    {
        picture: "44.png",
        value: 4,
        name: "4D"
    },
    {
        picture: "45.png",
        value: 3,
        name: "3C"
    },
    {
        picture: "46.png",
        value: 3,
        name: "3S"
    },
    {
        picture: "47.png",
        value: 3,
        name: "3H"
    },
    {
        picture: "48.png",
        value: 3,
        name: "3D"
    },
    {
        picture: "49.png",
        value: 2,
        name: "2C"
    },
    {
        picture: "50.png",
        value: 2,
        name: "2S"
    },
    {
        picture: "51.png",
        value: 2,
        name: "2H"
    },
    {
        picture: "52.png",
        value: 2,
        name: "2D"
    }
];

